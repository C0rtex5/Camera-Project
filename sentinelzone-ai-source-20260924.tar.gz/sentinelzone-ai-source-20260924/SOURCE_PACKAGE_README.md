# SentinelZone AI — portable source package

This package contains the application source and Docker build files needed to build and run SentinelZone AI on a test server. It is a source package, not a prebuilt image archive.

## Build and run on the test server

```sh
tar -xzf sentinelzone-ai-source-20260924.tar.gz
cd sentinelzone-ai-source-20260924
docker build -f Dockerfile -t sentinelzone-ai:test-server .
docker run -d --name sentinelzone-test \
  -p 127.0.0.1:18080:8000 \
  -v sentinel-test-data:/opt/sentinelzone/data \
  sentinelzone-ai:test-server
```

Open `http://127.0.0.1:18080/`. The bundled demo hub works without a camera or internet connection. Camera setup is available at `/setup`.

For the hardened Compose path:

```sh
docker compose up --build -d
```

The base Compose configuration binds only to localhost. Put an authenticated TLS reverse proxy in front of it before exposing it to an untrusted network.

## Optional GPU build

```sh
docker build -f Dockerfile.gpu -t sentinelzone-ai:test-server-gpu .
docker compose -f compose.yaml -f compose.gpu.yaml up -d
```

The CUDA image requires an NVIDIA driver and NVIDIA Container Toolkit on an x86 server. `Dockerfile.edge` is included as a legacy Jetson artifact and is not the supported x86 test-server recipe.

## Live camera and models

The package intentionally excludes credentials, SSH keys, camera calibration, trained model weights, and private runtime data. To test live monitoring:

1. Put a camera-compatible detector at `models/detector.pt`.
2. Put a validated, camera-fingerprint-matched forecast checkpoint at `models/forecast.pt`.
3. Use the `compose.live.yaml` overlay to mount `./models:/models:ro`.
4. Complete the RTSP URL, camera username/password, measured dimensions, and calibration in the setup panel.
5. Start monitoring only after the setup status reports all requirements satisfied.

For an SSH camera tunnel, place the private key and independently verified known-hosts file under `ssh/`, then use `compose.ssh.yaml`. Keep those files readable by UID `10001` and never commit them.

## Tests and utilities

The package includes the Python regression suite, browser checks, calibration tool, forecast-training utility, demo-asset builder, and Docker smoke tests:

```sh
python scripts/run_tests.py
node tests/hub.test.cjs
node tests/live_dashboard.test.cjs
```

The full image-level checks require Docker and may use disposable test resources. They do not substitute for testing the physical camera or site-specific model accuracy.

## Included runtime data

The package includes the curated demo scenarios and local browser dependencies under:

```text
src/demo_assets/
src/dashboard/assets/
```

It does not include the repository's raw datasets, recorded videos, model files, `.env.production`, Git history, virtual environments, or generated Python caches.
