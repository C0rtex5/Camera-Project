# Validation record — 2026-09-23

- CPU image built on the available Docker Engine: `sentinelzone-ai:production`.
- Image ID: `sha256:a617cbfff0e9f806fa876e426769d9baf3081eef921de96fd28d93b5f5c256a8`.
- Image smoke test exited 0 as UID 10001 with a read-only root filesystem, dropped capabilities, temporary storage, and an isolated data volume. Verified application imports, public login page, liveness, authentication rejection, unavailable-camera readiness (503), disabled demo routes, and lifecycle cleanup. Camera service was mocked for this test; no real camera or model was substituted silently.
- Full isolated regression suite: **82 tests passed**, 57.701 seconds, Python 3.11.16 and the pinned CPU dependencies. Includes original APIs, demo playback, core tracking/conflict code, production authentication and lifecycle, empty-scene detection, camera disconnect and calibration mismatch, invalid model outputs, checkpoint metadata validation, synthetic training artifact generation, mixture-mode collision mass, time-aligned risk thresholds, and status responsiveness during slow inference.
- Dependency consistency check passed. Compose YAML parsed. Git whitespace checks passed.
- CPU detector-only smoke measurement: 55.7 ms median / 59.0 ms maximum for ten warmed calls on `dam_sample_0.jpg`, two PyTorch threads, approximately 416 MiB peak process RSS. These are not full camera-pipeline performance figures.
- The CPU image is approximately 2.70 GB uncompressed; it retains PyTorch and the original agent dependencies. No claim of a tiny image is made. The application defaults to one camera, two CPU threads, bounded latest-frame storage, and a five-inference-per-second cap.

Still pending: real camera RTSP connectivity, measured calibration, representative reviewed training/validation recordings, camera-aligned forecast training, end-to-end alert and latency testing, and actual relay integration if required. The repository's relay flag is not a physical actuator.

The original local video file was already represented as modified by Git LFS before work began and was left untouched. Test-generated repository incident/manifest changes were restored; subsequent runs use isolated temporary output directories.

## Additional production corrections

- Collision risk now sums the probability mass of colliding forecast modes at each time step. It no longer misses a collision merely because probability is split across several similar forecast paths, nor combines an early low-probability event with an unrelated later peak.
- Camera status and capture no longer wait on the forecasting lock. The default freshness limit is one second and can be set per camera using `stale_after_seconds`.
- The RTSP integration runner creates only isolated test resources, uses no host port bindings, and deletes its containers, volumes, and network afterward. The test stream is a local repository image encoded as H.264; it is not a physical security camera.
- The final image also passed an unmocked RTSP/HTTP integration test through Uvicorn: real H.264/TCP decoding, YOLO inference, authenticated readiness and JPEG responses, publisher interruption, stale-telemetry removal, publisher restart, recovered monitoring, and logged graceful shutdown. The checkpoint was trained and evaluated on explicit synthetic fixtures solely for the test and remained inside the disposable volume. MediaMTX dependency image: `sha256:00ef3d1a243f3769ca36769b47df241a0c269c83a7735005b817505c49adb651`.

## Dependency refresh

The runtime was upgraded to PyTorch 2.14.0 / Torchvision 0.29.0 and patched API and agent libraries after advisory scanning identified vulnerabilities in the previous pins. All 82 regression tests pass with the upgraded dependencies and camera setup. The installed CPU image inventory (86 packages) reports no known Python-package advisories on 2026-09-23. This is not an OS, driver, CUDA-native-library, or comprehensive security assessment.

Evidence: [CPU package inventory](validation/cpu-image-inventory.json), [Python advisory scan](validation/cpu-python-audit.json), and [RTSP integration result](validation/cpu-rtsp.log).

Runtime lock SHA-256: `e1640d93cad9b9eed30754138be495e8eaa3cc4463aa7a6243842d11e471c2ea`.

## GPU and fallback validation

- Optional image built and tagged locally as `sentinelzone-ai:production-gpu`, ID `sha256:8b7efb57e2155810cfc812bcaef6f83eb18c0dd0e4b411d1ba5c97592c5a7476`.
- CUDA 12.6 / PyTorch 2.14.0 image passed the same real RTSP/Uvicorn integration test on the available NVIDIA GeForce RTX 3060. The detector and health endpoint reported `cuda:0`.
- The same image, with no GPU device exposed, passed the full test and reported `cpu`. This verifies automatic selection at startup; it does not promise recovery from a GPU failing during inference.
- Both checks cover authenticated readiness/JPEG, publisher loss, stale telemetry removal, reconnect, and graceful shutdown. Fixtures and training data were synthetic; no physical camera was connected.
- The GPU image is approximately **12.00 GB uncompressed**, versus **2.70 GB** for CPU. CUDA dependencies account for the larger optional image. CPU remains the default for the initial one-camera deployment.
- Installed GPU image inventory: 105 Python packages, no known Python-package advisories found on 2026-09-23. Native CUDA/driver/OS vulnerabilities were not assessed by this scan.

Evidence: [GPU package inventory](validation/gpu-image-inventory.json), [Python advisory scan](validation/gpu-python-audit.json), [CUDA integration](validation/gpu-rtsp.log), and [CPU fallback](validation/gpu-cpu-fallback.log).

## Browser freshness regression

Four JavaScript failure-scenario tests pass: a hanging next request clears previously displayed video/telemetry at expiry, a delayed image is discarded, reconnecting rejects an older in-flight response, and request timeout clears current content. The browser uses the camera's configured freshness threshold and conservatively includes request elapsed time. A watchdog runs independently of request completion. Run with `node tests/live_dashboard.test.cjs`; these tests exercise the page script with a simulated browser clock and network, not visual browser rendering.

Evidence: [dashboard regression output](validation/live-dashboard-tests.log).

The images were rebuilt after the freshness correction. CPU, CUDA, and GPU-image CPU fallback integration tests all passed again; installed package inventories are unchanged from the advisory-scanned versions.

## Separate camera setup panel

The production interface opens with no camera profile, source URL, detector, or forecasting checkpoint. `/setup` is a public login shell; its setup APIs require the application token in both production and demo modes. Drafts can omit camera data and remain editable. Passwords are persisted in a mode-0600 file in the data volume, are never included in API responses, and can be explicitly cleared. Setup responses disable caching. Saving does not interrupt active monitoring; starting is a separate action.

The full 82-test Python suite passed; final lifecycle/authentication checks (4 tests) and all 4 browser-script freshness tests passed. A real browser verified unlocking, saving an empty draft, and reopening the panel after server restart. Both final Docker images passed setup-only tests with a read-only root and no network; see [CPU setup](validation/cpu-setup.log) and [GPU setup](validation/gpu-setup.log).

The CPU image passed the existing legacy RTSP configuration test. The GPU image passed RTSP tests via saved setup and the start endpoint with both CUDA and CPU fallback (`scripts/docker_rtsp_smoke.py --setup`, plus `--gpu` for CUDA). These trained explicit synthetic fixture checkpoints, saved the matching calibration via the setup API, activated monitoring, verified forecast availability and JPEG output, interrupted the publisher, and recovered. They do not depend on real camera credentials.

Repeat setup-only image verification with `python scripts/docker_setup_smoke.py --image sentinelzone-ai:production` (or `production-gpu`). Both final image package inventories match the advisory-audited versions.

## Restored showcase hub

The final CPU and GPU builds above include the shared showcase-style hub, setup styling, local browser dependencies, and three isolated demo bundles. The full Python suite passed 82 tests. Seven additional hub JavaScript tests passed: stalled-response expiry, delayed image rejection, source-generation rejection, truthful defaults/PPE, unavailable WebGL, expired authentication, and hidden-tab fetch suspension. The four older dashboard tests describe the retained legacy page, not coverage of the new hub.

Browser checks at desktop size verified the split camera/ground-plane layout, original dark palette and panel arrangement, blue/amber detections, demo play/pause, stepping, scrubber, speed, orbit/zoom, a frame-specific review, source switching, missing-camera clearing, unavailable supervisor, setup navigation and incomplete saving. Dynamic measurements and explicit demo labels intentionally differ from the showcase. Automated setup tests additionally verified private credentials and persisted reload across application lifecycles.

Both images passed setup and demo tests with networking disabled and read-only root filesystems. Demo frames were authenticated, browser dependencies were local, and the legacy inference service remained uninitialized. Ten in-process demo API requests measured median 4.04 ms / peak process RSS 334.1 MiB on CPU and 4.26 ms / 594.6 MiB with the GPU image (without GPU inference). These are playback API measurements, not browser FPS, camera latency, or inference benchmarks.

Final RTSP tests passed on CPU, RTX 3060 CUDA, and GPU-image CPU fallback. The probe also asserted atomic JPEG/frame dimensions/timestamp, exported model-path consistency, a live review bound to the captured frame, and snapshot unavailability after disconnect. A deterministic model-output unit test verifies selected-mode path export. The fixture checkpoints are synthetic and establish pipeline behavior only. Installed package inventories are unchanged from the advisory-scanned versions.

Evidence: [Python results](validation/python-tests.log), [hub script tests](validation/hub-tests.log), and the setup/RTSP logs linked above. Real camera calibration, forecasting accuracy and deployment-machine end-to-end performance remain unvalidated until the actual camera and representative reviewed recordings are available.

## Optional camera setup follow-up

Added a direct “Explore demo — no camera needed” entry that selects demo even when a live camera exists, optional setup labels, and a setup skip link. Application-token authentication remains required. The browser verified demo entry and the skip link; all seven hub regressions passed again. No inference, credential, or camera behavior changed.

Refreshed images: CPU `sha256:37888d94cca11a141bdce9dda231ad87a3d19ba285b6ccf4fdc0cf5909a6f181`; GPU `sha256:e3bf5ffbbf394d3368ebfde108c24c9768dd68e6c850e9763757adc62321e3ac`. The full RTSP and Python results above apply to the preceding build; this follow-up repeats offline setup/playback smoke checks for the UI-only change.

## Credential-free showcase correction

The previous optional-setup follow-up still required an application token for demo access. This is corrected: a fresh visit now opens the bundled demo without any credentials. The live access window is dismissible. Public GET-only showcase routes expose only bundled assets and no camera configuration or mounted recordings. Live/setup/private hub APIs and stored reviews remain authenticated. Anonymous review buttons report a local preview, explicitly not saved.

Verified a fresh browser reload without entering a token, playback, preview adjudication, and closing the Access window. Seven hub JavaScript regressions and three backend hub tests passed (5.937 seconds for the latter), including public demo access and rejection of unauthenticated live/setup/review requests. The preview server was restarted and both open hub tabs refreshed.

Current production image: `sha256:dbfe1db59bfb75f8f6f33c5969b2079a8b7fbf503598a13f85daec73a549059d`. Offline anonymous-demo and protected-setup checks passed; see `validation/public-demo-cpu.log`.

Current production-gpu image: `sha256:36f3cc1bf9ea9bb17988e449200516546cdbd6fd1a5eb38b48e67f22f7f31633`. Offline anonymous-demo and protected-setup checks passed; see `validation/public-demo-gpu.log`.

## Application login removed at user request

This supersedes the authentication descriptions above: application-token enforcement and its UI have been removed for now. Camera setup loads immediately, and the camera's own username/password remain the credentials used for its RTSP connection. Live and demo review APIs operate without an application login. Anyone who can reach the app can use its APIs; Docker remains bound to localhost. Password storage remains mode 0600 and passwords are never returned by the setup API.

Full Python regression suite: 82 passed in 56.990 seconds. Six applicable hub JavaScript regressions passed; the obsolete token-expiry UI test was removed. Browser checks verified the absence of Access/login controls, directly editable setup, and incomplete draft saving without credentials. The preview server runs without an application token.

Both candidate images passed offline playback and setup persistence without SENTINEL_API_TOKEN or Authorization headers. CPU candidate: `sha256:1777491c50e1a161c2444927a9149a032ba6f8873e28c15b76edac9695237241`; GPU candidate: `sha256:926d8775b9344bcc5fc666ce2dffea0a4fc9a6a5d7fb2d6aa756d6f0b2cf56c3`. Evidence: `validation/no-token-cpu.log` and `validation/no-token-gpu.log`. Automatic approval review blocked promotion to production tags pending explicit approval of token removal across setup, live, hub and review APIs. Production tags remain on the previous authenticated build; the local preview uses the updated source.

## SSH camera tunnel field

Camera setup now persists an optional `ssh -p PORT username@server` field. It forwards RTSP/TCP through a loopback-only OpenSSH connection, using a host-provided private key and strictly verified known-hosts file. Saving does not contact the remote server. The existing monitoring activation opens the tunnel; it retries a lost SSH process and closes on service shutdown. Shell commands and extra SSH options are rejected. Camera passwords are excluded from SSH command arguments. Dockerfiles include openssh-client; `compose.ssh.yaml` mounts private SSH files read-only.

87 Python tests passed in 53.226 seconds, including five new tunnel tests for parsing, credential separation, draft persistence, failure cleanup and shutdown. Browser verification saved the supplied SSH example and confirmed it survived reload, with missing key/host prerequisites displayed. No actual connection to the example server was attempted: its private key, verified host key and remote camera details are not configured. Docker recipes changed; images were not rebuilt or promoted for this follow-up. Earlier production promotion remains pending the separately requested authentication approval.

## Remote tunnel container verification

Built CPU `sentinelzone-ai:remote-candidate` (`sha256:9e7a8093485843b2303eba24f122711038bbb3461fe53c64e3eaeab05d3e7397`) and GPU `sentinelzone-ai:remote-gpu-candidate` (`sha256:d075365f4bf0a27134b5925d62657a9562d5382978d598f831f92ec9d0baa5a5`). Both include OpenSSH and passed offline setup/playback plus real private-key SSH forwarding, wrong-host-key rejection, server restart recovery and graceful tunnel shutdown. The probes ran as the image's non-root user with read-only root filesystems, isolated data volumes and no published ports.

RTSP decoding, inference, synchronized snapshots, frame-bound reviews, publisher loss/recovery and shutdown passed on CPU, RTX 3060 CUDA, and GPU-image CPU fallback. A further combined CPU test routed the actual RTSP stream through the SSH tunnel using the saved camera setup field and passed the same pipeline checks. The test SSH keys and servers were disposable. All test resources were removed by the runners. Evidence: `validation/remote-ssh-{cpu,gpu}.log`, `remote-setup-{cpu,gpu}.log`, `remote-rtsp-{cpu,gpu,fallback}.log`, and `remote-rtsp-through-ssh.log`.

The actual test server has not been contacted: its key path, verified known-hosts file and camera RTSP details are still required. These tests use a synthetic forecasting checkpoint, not a site-validated model. Production tags remain unchanged; the remote candidates are ready for a later approved deployment.

## Current standalone candidate validation — 2026-09-24

The refreshed CPU candidate was built from the current worktree with `Dockerfile` and tagged `sentinelzone-ai:standalone-20260924-candidate`:

- Image ID: `sha256:304e195640afd04864f1d65ca7a50b0d94c5299495294250eaaa1e7928807d05`
- Uncompressed size: approximately 2.71 GB
- Runtime user: `10001:10001`; liveness health check: `/health`; one Uvicorn worker
- The image contains the local dashboard assets and three bundled demo scenarios, but no repository data, `.env`, camera configuration, SSH keys, detector weights, or forecast checkpoint.

The pinned-image regression gate passed **91 Python tests** in an isolated read-only, network-disabled container. Both browser suites passed: 6 hub tests and 4 legacy live-dashboard tests. The setup smoke test passed with no camera, no network, a fresh data volume, incomplete setup persistence, private mode-0600 password storage, and no demo inference worker.

The refreshed optional GPU candidate is `sentinelzone-ai:standalone-20260924-gpu-candidate`, image ID `sha256:8f09425401dd1210dc24e3161374dd315209c16dc218690920f39ad4b3e9593f` (approximately 12.0 GB). Its setup smoke test passed. Controlled H.264/TCP RTSP integration passed for:

- the CPU image on CPU;
- the GPU image with an NVIDIA device exposed (`cuda:0`); and
- the GPU image without a device exposed (CPU fallback).

All three paths verified real stream decode, detector/API output, disconnect clearing, reconnect recovery, and graceful shutdown. The RTSP fixture and synthetic checkpoint are test-only; they do not validate the physical camera, site calibration, or forecasting accuracy.

