# Production deployment — one camera

The default image uses CPU inference. The optional NVIDIA image selects CUDA when available and otherwise selects CPU. The CPU image intentionally contains no CUDA libraries and cannot use a GPU. The application keeps one pending frame, defaults to five inference cycles per second, and uses two PyTorch CPU threads. Actual throughput must be measured on the deployment machine. Results older than one second are stale by default; `stale_after_seconds` in the camera profile controls this limit. Status reads remain responsive while the forecasting model runs.

## Required site inputs

- A reachable RTSP stream. ONVIF discovery is not implemented; obtain the RTSP URL from the camera vendor.
- A camera-specific calibration for the exact stream resolution and the same metric datum used by site manifests. `K` is the camera intrinsic matrix, `dist` the distortion coefficients, and `H` maps metric ground coordinates to undistorted pixels. Do not reuse the demo calibration. The example intentionally contains null matrices and will fail validation.
- Local detector weights at `weights/detector.pt`, plus a trained, validated forecasting checkpoint at `weights/forecast.pt`. No forecasting checkpoint is shipped in this repository. The checkpoint must match this GNN implementation; PyTorch Geometric-trained checkpoints require its optional dependency and a matching image build. An untrained checkpoint is not a substitute. COCO detectors do not provide PPE classification; PPE status is unknown for those models.
- Camera username and password, if the camera requires authentication. No application access token is used.

## Start

1. Build and start the demo-first image: `docker compose up --build -d`. The application does not require an environment file, camera, calibration, or model files for the bundled demo.
2. To provide optional deployment variables, create `.env.production` from `.env.production.example`, restrict it with `chmod 600`, and start with `docker compose --env-file .env.production up --build -d`. Camera credentials can remain blank.
3. Open **Camera setup** from the dashboard (or `/setup`).
4. Enter the RTSP address, camera username, and password in separate fields. **Save setup** accepts incomplete drafts, so remaining details can be supplied later. Blank password preserves the saved value; the removal checkbox explicitly clears it.
5. Add measured stream dimensions and calibration when available. Install detector and validated forecasting weights in the mounted `weights/` directory using the explicit `SENTINEL_DETECTOR_WEIGHTS` and `SENTINEL_GNN_CHECKPOINT` paths. The panel lists unmet requirements.
6. Select **Start monitoring** when setup is complete. If already monitoring, save edits and restart the service to apply them. A complete saved setup also starts automatically after restart.
7. `/health` reports process liveness; `/ready` remains 503 until live monitoring is ready. An empty or incomplete setup does not claim monitoring is operational.

The private draft is stored at `data/setup/camera.json` in the persistent data volume with file permissions 0600. Passwords are stored on the server and never returned by the setup API; protect backups of this volume. The setup API opens directly without application login. Saving camera credentials does not contact the camera; monitoring activation does.

Legacy environment/file setup remains supported when no saved panel draft exists. Mount your calibrated JSON at `SENTINEL_CAMERA_CONFIG` and provide its source environment variables to use that workflow. The default Compose file no longer mounts a camera file that may not exist.

For NVIDIA servers with Docker Compose 2.30+ and NVIDIA Container Toolkit installed, use `docker compose -f compose.yaml -f compose.gpu.yaml up --build -d`. This is an x86 server configuration, not a Jetson image. `Dockerfile.edge` is the legacy Jetson artifact and is not the supported production recipe.

Keep a single server worker: multiple workers would open duplicate camera connections. Put an authenticated TLS reverse proxy in front of the localhost-bound service for remote access. Do not place credentials in URLs. Camera credentials are environment variables and are excluded from JSON telemetry.

## Preserved functions and limits

Detection, metric projection, EKF tracking, GNN forecasting, conflict evaluation, incident APIs, permit compilation, agent tools, and the original demo dashboard remain in the source. Legacy demo video APIs are disabled in production. The `/api/v1/hub/demo/` adapter serves explicitly labeled, isolated recorded scenarios without starting inference. Agent calls require an explicitly configured provider and model in production; deterministic example responses are not allowed as a production fallback. Permit compilation additionally requires an actual IFC model and the optional `ifcopenshell` dependency. The existing incident analysis consumes text telemetry; it does not fetch or visually inspect a supplied video URL. Physical relay actuation remains an in-memory flag, not an implemented hardware driver.

The Docker volume retains manifests and incident adjudications. Back up that volume. Container logs rotate. A stopped or stale stream exposes no current safety telemetry; `/health` alone does not indicate operational monitoring. Test disconnect/reconnect, camera resolution changes, inference failure, restart recovery, CPU load, and alert behavior with controlled footage before site operation.

The CPU and GPU images passed isolated RTSP integration tests, including actual RTX 3060 inference and CPU fallback; see [VALIDATION.md](VALIDATION.md). Actual camera connectivity, trained model accuracy, site calibration, and performance on the deployment hardware still require validation. Passing unit tests does not establish those properties.

Backend references: [OpenCV capture timeouts](https://docs.opencv.org/4.10.0/d4/d15/group__videoio__flags__base.html) and [Docker GPU allocation](https://docs.docker.com/reference/compose-file/services/#gpus).

Local CPU smoke measurement (repository sample image, YOLOv8n, ten warmed calls, two PyTorch threads): median 55.7 ms, maximum 59.0 ms, peak process RSS about 416 MiB. This excludes RTSP decoding, GNN execution, and the HTTP service and is not a site performance guarantee.

The checkpoint format and the camera-aligned training workflow are documented in [FORECAST_TRAINING.md](FORECAST_TRAINING.md). Bare legacy checkpoints are not accepted by the production live-camera loader.


## RTSP integration test without a physical camera

After building the CPU image, run `python scripts/docker_rtsp_smoke.py` on a host with the Docker socket available. The test uses an isolated Docker network with no host ports, publishes the repository sample image as H.264 over RTSP/TCP, and runs the actual camera worker, detector, API, and shutdown path. It stops and restarts the publisher and checks readiness and JPEG availability. All test containers, data volumes, and the test network are removed afterward.

The forecasting artifact used by this test is trained for one epoch on explicit synthetic fixtures inside a disposable volume. It is never installed in `weights/forecast.pt` and does not establish site-model accuracy. The MediaMTX test dependency follows its [documented Docker and FFmpeg workflow](https://mediamtx.org/docs/kickoff/install).

The collision engine reports the summed mixture-mode mass of colliding mean trajectories at each forecast instant. This fixes undercounting when several plausible modes predict the same collision. Severity uses probability and time-to-collision from the same instant. This score is not a separately calibrated probability of a real-world incident.

To produce the required camera matrix from measured survey points, follow [CAMERA_CALIBRATION.md](CAMERA_CALIBRATION.md). This creates the camera profile and fingerprint needed by the training workflow without using the demo calibration.


## Image size and verification

The tested CPU image is about 2.66 GB uncompressed; the optional GPU image is about 11.96 GB because it includes CUDA libraries. Use the CPU image for the initial deployment to avoid carrying those libraries. Switching images does not change the calibration/checkpoint contract or the persistent data volume.

To repeat GPU validation on a compatible host, run `python scripts/docker_rtsp_smoke.py --image sentinelzone-ai:production-gpu --gpu`. To verify CPU fallback in that same image, omit `--gpu`. The runner expects CUDA in the first test and CPU in the second.

Both installed Python package inventories were scanned after building, with no known advisories found on the validation date. Recheck advisories when deploying or updating; these scans do not assess the OS, GPU driver, or native CUDA libraries.

## Shared detection hub and offline playback

Both modes serve the same split-view hub at `/`. There is no application-token login or Access window. Recorded scenarios open immediately, and live cameras can be selected directly. Camera setup is optional and opens directly; enter the camera's username and password there when available. Losing live monitoring clears camera overlays, 3D objects, and metrics; it never switches to demo automatically. Playback controls apply only to demo footage. Incomplete camera drafts remain supported.

Three curated scenarios (240 sampled JPEG frames, approximately 20 MB total) ship with the image. All browser scripts, including Three.js and its license, are local. Runtime internet access and production model weights are unnecessary for demo playback. Demo geometry and linear paths are illustrative and explicitly labeled; they are not live GNN predictions or validation results. The comparison table uses “Not measured” for unavailable benchmarks. COCO-only PPE remains unknown.

Live snapshots carry the image, frame identity, dimensions, capture time, histories, model forecast paths, hazards, conflicts, and measured cycle latency together. The browser rejects expired and superseded responses, caps 3D rendering at 30 FPS, and suspends it in hidden tabs. Reviews resolve the displayed frame on the server, expire after five minutes or cache eviction, and retain telemetry snapshots. Demo reviews live in `data/demo_reviews`; live reviews in `data/adjudications`. No live video recording is added.

Optional additional curated bundles can be mounted read-only using `docker compose -f compose.yaml -f compose.demo.yaml up -d`. Place each bundle in `demo-library/<scenario>/` with `manifest.json` and numbered JPEGs (`0000.jpg`, etc.). Use a safe scenario name (letters, digits, underscore, hyphen; maximum 64 characters), at most 1,000 frames and a manifest under 20 MB. Follow the bundled manifest schema in `src/demo_assets/`: title, provenance, playback fps, and per-frame dimensions, timestamp, detections, tracks, illustrative paths and hazards. This is a prepared playback format, not an automatic raw-video importer. `scripts/build_demo_assets.py` documents offline curation from repository clips. The original raw-video APIs remain available only in demo mode.

Application APIs, including camera setup and reviews, no longer require a token. Anyone who can reach the application can use them; the supplied Docker configuration remains bound to localhost. Camera passwords are still stored privately and never returned by the setup API. Demo and live reviews are saved separately. Hub and setup API responses disable caching. Non-root execution, the read-only root filesystem and private persistent data volume are unchanged.

## Optional camera tunnel through an SSH test server

Camera and site names may contain spaces; saved identifiers use hyphens. Invalid fields now report their own validation errors without returning credential values. A failed save does not attempt a network connection.

Use **Check connection** to test the current form without saving it: the application verifies SSH, then receives one RTSP video frame in a bounded subprocess. This check does not require dimensions, calibration, a detector or a forecasting checkpoint, and stores no recording. **Start monitoring** still requires those AI prerequisites. SSH and RTSP authentication are distinct; correct camera credentials cannot replace an SSH private key.

The setup form accepts **SSH private-key file path** and **Verified SSH known-hosts file path** on the application host. Blank paths use `SENTINEL_SSH_KEY_FILE` and `SENTINEL_SSH_KNOWN_HOSTS`. Container paths refer to the mounted files inside the container. Keys remain in files, never in API responses. Host-key verification remains strict. Connection diagnostics distinguish SSH authentication, host verification, timeout/refusal, and camera authentication or stream-path errors without exposing raw process output.

In Camera setup, enter `ssh -p 22022 abhay_m@87.103.13.53` in **SSH tunnel to test server (optional)**. Enter the camera RTSP address as reachable from that server, plus the camera's own username/password. Saving stores a draft only. The existing Start monitoring action opens a loopback-only SSH forward and connects the RTSP/TCP worker through it. Leave the SSH field blank for direct camera access. This is a camera tunnel, not remote deployment or a remote shell.

The current tunnel supports key authentication. On the application host, set `SENTINEL_SSH_KEY_FILE` to a readable private key and `SENTINEL_SSH_KNOWN_HOSTS` to a file containing the independently verified server host key (for the example, host entry `[87.103.13.53]:22022`). Unknown or changed host keys are rejected. Password-only SSH and interactive key passphrases are not supported. No camera password is passed to SSH.

For Docker, use `docker compose -f compose.yaml -f compose.ssh.yaml up --build -d` and provide `ssh/id_ed25519` and `ssh/known_hosts`, readable by container UID 10001. Keep the private key owner-only; do not make it world-readable. This directory is ignored by Git and mounted read-only. Both Dockerfiles install the OpenSSH client. The tunnel uses one process, retries a lost SSH session, and shuts down with the camera service. Camera freshness checks continue to clear stale data during a tunnel outage. RTSP over TCP is supported; RTSPS through this forwarding mode is rejected rather than bypassing TLS hostname checks.

The example host is not contacted when the field is saved. An actual connection requires the SSH key, verified host key, remote camera address, measured calibration and models. Missing tunnel requirements appear in setup status.

### Reproduce the container tunnel checks

Build the disposable SSH fixture with `docker build -f tests/integration/Dockerfile.ssh -t sentinelzone-ai:ssh-test-fixture .`. This fixture is only for isolated tests, never a deployment server. `python scripts/docker_ssh_smoke.py --image sentinelzone-ai:remote-candidate` creates temporary keys, checks strict host verification, exercises real forwarding, restarts the test SSH server, and confirms process cleanup. It exposes no host ports and removes its containers, volumes, network and keys afterward.

`python scripts/docker_rtsp_smoke.py --image sentinelzone-ai:remote-candidate --ssh` additionally runs an actual RTSP stream, detector, synthetic fixture forecaster and API through SSH. It tests publisher interruption and recovery. Use a cached MediaMTX image ID with `--media-image` for offline tests. These checks establish transport and application behavior, not the accuracy of a real site's forecasting model.

The tested container candidates are `sentinelzone-ai:remote-candidate` (CPU) and `sentinelzone-ai:remote-gpu-candidate` (optional NVIDIA). They include the current application with no application-token login. Production image tags are unchanged pending the previously requested deployment approval. A real connection also requires the user's private key, independently verified server host key and camera setup; sample keys from the tests are never installed for that purpose.
