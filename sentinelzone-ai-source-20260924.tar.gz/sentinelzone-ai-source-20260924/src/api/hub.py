"""Display adapters. Demo playback never constructs an inference worker."""
import base64
from collections import OrderedDict
import copy
from functools import lru_cache
import json
import os
from pathlib import Path
import re
import threading
import time
import uuid

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parents[1] / 'demo_assets'
LOCK = threading.RLock()
SNAPSHOTS = OrderedDict()


def remember(packet):
    key = (packet['source'],packet['frame_id'])
    with LOCK:
        SNAPSHOTS[key] = (time.monotonic(),copy.deepcopy({k:v for k,v in packet.items() if k!='jpeg'}))
        SNAPSHOTS.move_to_end(key)
        while len(SNAPSHOTS)>128:SNAPSHOTS.popitem(last=False)
    return packet


@lru_cache(maxsize=4)
def read_manifest(path, modified, size):
    return json.loads(Path(path).read_text())


def demos(bundled_only=False):
    result = {}
    roots = [ROOT]
    if not bundled_only and os.getenv('SENTINEL_DEMO_DIR'): roots.append(Path(os.environ['SENTINEL_DEMO_DIR']))
    for root in roots:
        if not root.exists():continue
        for folder in sorted(root.iterdir()):
            if not folder.is_dir() or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',folder.name):continue
            manifest = folder/'manifest.json'
            if not manifest.is_file() or manifest.stat().st_size>20_000_000:continue
            try:
                data=read_manifest(str(manifest.resolve()),manifest.stat().st_mtime_ns,manifest.stat().st_size)
                if not isinstance(data['frames'],list) or not 0<len(data['frames'])<=1000:continue
                result[folder.name]=(folder,data)
            except (ValueError,KeyError,TypeError):continue
    return result


def live_packet(worker):
    with worker.lock:
        state=worker.snapshot()
        if state['state']!='STREAMING' or not worker.jpeg or not worker.frame_id:
            raise HTTPException(503,'Camera monitoring unavailable')
        data=copy.deepcopy(worker.telemetry)
        data.update(source='live',camera_id=worker.config.camera_id,site_id=worker.config.site_id,
                    device=state['device'],frame_age_seconds=state['frame_age_seconds'],
                    stale_after_seconds=worker.config.stale_after_seconds,
                    jpeg=base64.b64encode(worker.jpeg).decode('ascii'))
    return remember(data)


class Review(BaseModel):
    source: str = Field(pattern=r'^(live|demo)$')
    frame_id: str = Field(max_length=128)
    verdict: str = Field(pattern=r'^(TRUE_POSITIVE|FALSE_POSITIVE|CONTROLLED_WORK)$')


def router(get_live):
    r=APIRouter(prefix='/api/v1/hub')

    @r.get('/sources')
    def sources():
        service=get_live()
        return {'agent_configured':bool(os.getenv('SENTINEL_LLM_MODEL') and (os.getenv('OPENAI_API_KEY') or os.getenv('ANTHROPIC_API_KEY'))),
                'cameras':service.status() if service else [],
                'demos':[{'id':key,'title':data['title'],'frames':len(data['frames']),'fps':data.get('fps',5)}
                         for key,(_,data) in sorted(demos().items(),key=lambda item:({'blind_spot':0,'near_miss':1,'barrier':2}.get(item[0],3),item[0]))]}

    @r.get('/live/{camera_id}/snapshot')
    def snapshot(camera_id:str):
        service=get_live()
        worker=service.workers.get(camera_id) if service else None
        if worker is None:raise HTTPException(404,'Camera not configured')
        return live_packet(worker)

    def demo_frame(scenario:str,index:int, *, bundled_only=False):
        item=demos(bundled_only).get(scenario)
        if not item:raise HTTPException(404,'Demo not found')
        folder,data=item
        if index<0 or index>=len(data['frames']):raise HTTPException(404,'Frame not found')
        packet=copy.deepcopy(data['frames'][index])
        path=folder/f'{index:04d}.jpg'
        if not path.is_file():raise HTTPException(404,'Demo image unavailable')
        packet.update(source='demo',scenario_id=scenario,frame_id=f'{scenario}-{index}-{(folder / "manifest.json").stat().st_mtime_ns}',
                      device='Recorded playback',jpeg=base64.b64encode(path.read_bytes()).decode('ascii'),
                      provenance=data['provenance'],forecast_status='ILLUSTRATIVE_DEMO')
        return packet if bundled_only else remember(packet)

    @r.get('/demo/{scenario}/frames/{index}')
    def private_demo(scenario:str,index:int):
        return demo_frame(scenario,index)

    @r.post('/reviews')
    def review(req:Review):
        with LOCK:
            record=SNAPSHOTS.get((req.source,req.frame_id))
            if not record or time.monotonic()-record[0]>300:
                raise HTTPException(409,'Review frame expired. Capture a current frame and try again.')
            snapshot=copy.deepcopy(record[1])
        event_id=('DEMO-' if req.source=='demo' else 'LIVE-')+uuid.uuid4().hex
        target=Path('data/demo_reviews' if req.source=='demo' else 'data/adjudications')
        target.mkdir(parents=True,exist_ok=True)
        record={'event_id':event_id,'source':req.source,'verdict':req.verdict,'snapshot':snapshot,'reviewed_at':time.time()}
        tmp=target/f'.{event_id}.tmp'
        tmp.write_text(json.dumps(record,allow_nan=False))
        tmp.replace(target/f'{event_id}.json')
        return {'event_id':event_id,'status':'REVIEW_STORED','frame_id':req.frame_id,'source':req.source}
    public=APIRouter(prefix='/api/v1/showcase')
    @public.get('/sources')
    def public_sources():
        return {'agent_configured':False,'cameras':[],
                'demos':[{'id':key,'title':data['title'],'frames':len(data['frames']),'fps':data.get('fps',5)}
                         for key,(_,data) in demos(True).items()]}
    @public.get('/demo/{scenario}/frames/{index}')
    def public_frame(scenario:str,index:int):
        return demo_frame(scenario,index,bundled_only=True)
    combined=APIRouter()
    combined.include_router(r)
    combined.include_router(public)
    return combined
