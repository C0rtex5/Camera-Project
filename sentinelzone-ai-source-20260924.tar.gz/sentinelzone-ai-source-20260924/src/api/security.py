"""Authenticate HTTP and WebSocket traffic before routing in production."""
import secrets
import re
from starlette.responses import JSONResponse


class TokenAuthMiddleware:
    def __init__(self, app, token):
        self.app, self.token = app, token

    async def __call__(self, scope, receive, send):
        public_demo = scope['type']=='http' and scope.get('method')=='GET' and re.fullmatch(r'/api/v1/showcase/(sources|demo/[A-Za-z0-9_-]{1,64}/frames/[0-9]+)',scope.get('path',''))
        if public_demo or scope['type'] not in ('http', 'websocket') or (scope.get('path') in ('/health', '/', '/setup') or scope.get('path', '').startswith('/assets/')):
            return await self.app(scope, receive, send)
        headers = dict(scope.get('headers', []))
        supplied = headers.get(b'authorization', b'')
        if not secrets.compare_digest(supplied, ('Bearer ' + self.token).encode('utf-8')):
            if scope['type'] == 'websocket':
                await send({'type': 'websocket.close', 'code': 1008})
            else:
                await JSONResponse({'detail': 'Authentication required'}, status_code=401)(scope, receive, send)
            return
        await self.app(scope, receive, send)
