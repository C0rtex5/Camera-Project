"""Bounded, non-recording connection check independent of calibration and models."""
import json
import os
import subprocess
import sys

from src.api.ssh_tunnel import CameraTunnel

PROBE = '''
import cv2,json,os
cap=cv2.VideoCapture(os.environ['SENTINEL_PROBE_SOURCE'],cv2.CAP_FFMPEG,
 [cv2.CAP_PROP_OPEN_TIMEOUT_MSEC,8000,cv2.CAP_PROP_READ_TIMEOUT_MSEC,5000])
try:
 ok,frame=cap.read() if cap.isOpened() else (False,None)
 print(json.dumps({'ok':bool(ok),'width':int(frame.shape[1]) if ok else None,
                   'height':int(frame.shape[0]) if ok else None}))
finally:cap.release()
'''


def check_connection(draft):
    tunnel = None
    stage = 'ssh' if draft.ssh_tunnel else 'camera'
    try:
        source = draft.source()
        if draft.ssh_tunnel:
            tunnel = CameraTunnel(draft.ssh_tunnel, source, draft.ssh_key_file, draft.ssh_known_hosts)
            tunnel.start()
            source = tunnel.source
        stage = 'camera'
        result = subprocess.run([sys.executable, '-c', PROBE],
            env={**os.environ, 'SENTINEL_PROBE_SOURCE': source,
                 'OPENCV_FFMPEG_CAPTURE_OPTIONS': 'rtsp_transport;tcp'},
            capture_output=True, text=True, timeout=16)
        packet = json.loads(result.stdout) if result.returncode == 0 else {'ok': False}
        if packet.get('ok'):
            return {**packet, 'stage': 'connected', 'message': 'Camera connected and a video frame was received. AI monitoring has separate calibration and model requirements.'}
        error = result.stderr.lower()
        message = 'Camera did not return a video frame. Check its RTSP path, credentials and reachability from the SSH server or application host.'
        for marker, detail in [('401', 'Camera rejected RTSP authentication. Check the camera username and password.'),
                               ('404', 'Camera RTSP stream path was not found. Check the complete stream URL.'),
                               ('connection refused', 'Camera refused the RTSP connection. Check the camera address, port and streaming service.')]:
            if marker in error: message = detail; break
        return {'ok': False, 'stage': stage, 'message': message}
    except subprocess.TimeoutExpired:
        return {'ok': False, 'stage': stage, 'message': 'Camera connection timed out. Check camera reachability and the complete RTSP path.'}
    except ValueError as error:
        if stage == 'ssh':
            return {'ok': False, 'stage': stage, 'message': str(error)}
        return {'ok': False, 'stage': stage, 'message': 'Camera connection check failed to decode a response.'}
    except OSError:
        return {'ok': False, 'stage': stage, 'message': 'Connection check could not start. Check the SSH client and key-file access on the application host.'}
    finally:
        if tunnel: tunnel.close()
