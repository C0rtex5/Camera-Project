'use strict';
const el=id=>document.getElementById(id), canvas=el('vision-canvas'),ctx=canvas.getContext('2d');
let epoch=0,source='demo',catalog={cameras:[],demos:[]},index=0,playing=false,speed=1,timer=null,current=null,bitmap=null,deadline=0;
const twin=createTwin();
async function api(path,options={}){
 const response=await fetch(path,{...options,headers:{'Content-Type':'application/json'},cache:'no-store',signal:AbortSignal.timeout(options.timeout||5000)});

 if(!response.ok){const value=await response.json().catch(()=>({}));throw Error(typeof value.detail==='string'?value.detail:'Service unavailable ('+response.status+')');}
 return response.json();
}
function clear(message){current=null;deadline=0;if(bitmap){bitmap.close();bitmap=null;}ctx.clearRect(0,0,canvas.width,canvas.height);twin.clear();el('empty-message').textContent=message;el('empty-message').hidden=false;el('system-alert-badge').textContent='UNAVAILABLE';el('system-alert-badge').className='badge';for(const id of ['metric-ttc','metric-pcol','metric-latency'])el(id).textContent='—';el('gnn-status').textContent='Unavailable';el('forecast-label').textContent='Forecast unavailable';el('gnn-verdict').textContent='No current observations';el('comparison-context').textContent='No current observations';el('live-age').textContent='Unavailable';el('cam-telemetry-tag').textContent='No observations';document.querySelectorAll('.review').forEach(b=>b.disabled=true);}
function resize(){canvas.width=Math.max(1,canvas.parentElement.clientWidth);canvas.height=Math.max(1,canvas.parentElement.clientHeight);if(current&&bitmap)draw(current,bitmap);twin.resize();}
window.addEventListener('resize',resize);
function draw(packet,image){
 ctx.clearRect(0,0,canvas.width,canvas.height);
 const scale=Math.min(canvas.width/packet.frame_width,canvas.height/packet.frame_height),x=(canvas.width-packet.frame_width*scale)/2,y=(canvas.height-packet.frame_height*scale)/2;
 ctx.drawImage(image,x,y,packet.frame_width*scale,packet.frame_height*scale);
 (packet.detections||[]).forEach(d=>{const [x1,y1,x2,y2,confidence,cls]=d,worker=cls<2,color=worker?'#3b82f6':'#f59e0b';const left=x+x1*scale,top=y+y1*scale,w=(x2-x1)*scale,h=(y2-y1)*scale;ctx.strokeStyle=color;ctx.lineWidth=2;ctx.strokeRect(left,top,w,h);ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(left,top+12);ctx.lineTo(left,top);ctx.lineTo(left+12,top);ctx.moveTo(left+w-12,top+h);ctx.lineTo(left+w,top+h);ctx.lineTo(left+w,top+h-12);ctx.stroke();ctx.fillStyle=color;ctx.fillRect(left,Math.max(0,top-20),Math.min(200,canvas.width-left),20);ctx.fillStyle='white';ctx.font='bold 11px monospace';ctx.fillText((worker?'WORKER':cls===2?'HEAVY EQUIPMENT':'LIGHT VEHICLE')+' ['+Math.round(confidence*100)+'%]',left+4,Math.max(14,top-5));
 if(worker){ctx.fillStyle='#101215df';ctx.fillRect(left,top+h+2,142,19);ctx.fillStyle='#9ca3af';ctx.font='10px monospace';const ppe=(packet.ppe||[]).find(p=>p.bbox?.every((v,i)=>Math.abs(v-d[i])<1));ctx.fillText('PPE: '+HubCore.ppe(ppe?.ppe_compliant),left+4,top+h+15);}
 });
}
function display(packet,image,expires){
 if(bitmap)bitmap.close();bitmap=image;current=packet;deadline=expires;el('empty-message').hidden=true;draw(packet,image);twin.update(packet);
 const demo=packet.source==='demo',risk=HubCore.risk(packet),alarm=packet.debounced_alarm||'UNAVAILABLE';
 el('device').textContent=packet.device;el('source-label').textContent=demo?'RECORDED DEMO · NOT LIVE':'LIVE CAMERA';el('cam-telemetry-tag').textContent=packet.frame_width+'×'+packet.frame_height+(demo?' · Recorded':' · Live');
 el('forecast-label').textContent=demo?'Illustrative linear paths':packet.forecast_status==='AVAILABLE'?'GATv2 ST-GNN · '+packet.forecast_horizon_seconds.toFixed(1)+' s':'Forecast unavailable';
 el('metric-ttc').textContent=risk.ttc==null?(demo?'Not measured':'No predicted breach'):risk.ttc.toFixed(2)+' s';el('metric-pcol').textContent=risk.probability==null?'Not measured':(risk.probability*100).toFixed(1)+' %';
 el('metric-latency').textContent=Number.isFinite(packet.cycle_latency_ms)?packet.cycle_latency_ms.toFixed(1)+' ms':'Not measured';
 el('system-alert-badge').textContent=demo?'DEMO PLAYBACK':alarm==='NORMAL_LEVEL_0'?'NO CURRENT ALERT':alarm.replaceAll('_',' ');
 el('system-alert-badge').className='badge '+(demo?'':alarm.includes('CRITICAL')?'badge-alert-critical':alarm.includes('WARNING')?'badge-alert-warning':alarm.includes('ADVISORY')?'badge-alert-advisory':'badge-alert-normal');
 el('gnn-status').textContent=demo?'Not evaluated':packet.forecast_status==='AVAILABLE'?alarm:'Unavailable';el('gnn-verdict').textContent=demo?'Illustrative playback; no model validation':'Current camera model output';el('comparison-context').textContent=demo?'RECORDED DEMONSTRATION':'CURRENT LIVE FRAME';el('provenance').textContent=demo?packet.provenance:'Mode mass is not a calibrated incident probability. Lead time and false-alarm rates require site validation.';
 document.querySelectorAll('.review').forEach(b=>b.disabled=false);
 if(demo){el('frame-counter').textContent=(index+1)+' / '+selectedDemo().frames;el('scrubber').value=index;}
}
function selectedDemo(){return catalog.demos.find(d=>d.id===el('scenario').value);}
async function loadFrame(session=epoch){
 const started=performance.now();
 try{
  if(document.hidden)return;
  const demo=selectedDemo();const camera=catalog.cameras[0];
  if(source==='demo'&&!demo){clear('No demo assets found. Add a curated recording bundle.');return;}
  if(source==='live'&&!camera){clear('No live camera configured. Open Camera setup; demo playback remains available.');return;}
  const path=source==='live'?'/live/'+encodeURIComponent(camera.camera_id)+'/snapshot':'/demo/'+encodeURIComponent(demo.id)+'/frames/'+index;
  const packet=await api('/api/v1/hub'+path);const expires=HubCore.expires(packet,started);
  if(!HubCore.valid(packet,session,epoch,expires,performance.now())){if(session===epoch)clear('Camera frame is stale — monitoring unavailable');return;}
  const bytes=Uint8Array.from(atob(packet.jpeg),c=>c.charCodeAt(0));const image=await createImageBitmap(new Blob([bytes],{type:'image/jpeg'}));
  if(!HubCore.valid(packet,session,epoch,expires,performance.now())){image.close();if(session===epoch)clear('Camera frame is stale — monitoring unavailable');return;}
  display(packet,image,expires);
 }catch(error){if(session===epoch){clear(error.message);}}
 finally{if(session===epoch&&(source==='live'||playing)){const rate=source==='live'?5:(selectedDemo()?.fps||5)*speed;timer=setTimeout(()=>{if(source==='demo'&&playing&&!document.hidden)index=(index+1)%selectedDemo().frames;loadFrame(session);},Math.max(0,1000/rate-(performance.now()-started)));}}
}
function switchSource(){epoch++;clearTimeout(timer);source=el('source').value;playing=false;index=0;el('btn-play').textContent='Play';el('playback').hidden=source==='live';el('live-strip').hidden=source!=='live';el('scenario').hidden=source==='live';el('scene-title').textContent=source==='demo'?(selectedDemo()?.title||'Recorded demonstration'):catalog.cameras[0]?.camera_id||'Live camera';el('cam-title-tag').textContent=source==='demo'?'Recorded construction site footage':'Live security camera';el('review-status').textContent='Reviews reference the displayed frame.';clear('Loading '+source+' source…');el('scrubber').max=(selectedDemo()?.frames||1)-1;loadFrame(epoch);}
async function refresh(initial=false,preferDemo=false){catalog=await api('/api/v1/hub/sources');const previous=el('scenario').value;el('scenario').replaceChildren();for(const item of catalog.demos){const option=document.createElement('option');option.value=item.id;option.textContent=item.title;el('scenario').appendChild(option);}if(catalog.demos.some(d=>d.id===previous))el('scenario').value=previous;if(initial)el('source').value=preferDemo?'demo':HubCore.initial(catalog);switchSource();}
el('source').onchange=switchSource;el('scenario').onchange=switchSource;el('rescan').onclick=()=>refresh().catch(e=>clear(e.message));
function playPause(){if(source!=='demo')return;playing=!playing;el('btn-play').textContent=playing?'Pause':'Play';epoch++;clearTimeout(timer);if(playing)loadFrame(epoch);}
function step(delta){if(source!=='demo'||!selectedDemo())return;playing=false;el('btn-play').textContent='Play';epoch++;clearTimeout(timer);index=Math.max(0,Math.min(selectedDemo().frames-1,index+delta));loadFrame(epoch);}
el('btn-play').onclick=playPause;el('step-back').onclick=()=>step(-1);el('step-forward').onclick=()=>step(1);el('speed').onchange=()=>{speed=Number(el('speed').value);};el('scrubber').oninput=()=>{const target=Number(el('scrubber').value);step(target-index);};
async function review(verdict){if(!current)return;const captured={source:current.source,frame_id:current.frame_id,verdict};el('review-status').textContent='Saving review of '+captured.frame_id+'…';try{const r=await api('/api/v1/hub/reviews',{method:'POST',body:JSON.stringify(captured)});el('review-status').textContent=(r.source==='demo'?'Demo review':'Live review')+' saved for frame '+r.frame_id;}catch(e){el('review-status').textContent=e.message;}}
document.querySelectorAll('.review').forEach(b=>b.onclick=()=>review(b.dataset.verdict));
el('supervisor').onclick=()=>{el('agent').hidden=false;el('agent-context').textContent=source==='demo'?'Demo playback is isolated. Select Live camera for site supervision.':catalog.agent_configured?'Agent provider configured. Review recommendations against site conditions.':'Agent provider is not configured. Live camera monitoring remains available.';el('ask').disabled=source==='demo'||!catalog.agent_configured;};el('close-agent').onclick=()=>{el('agent').hidden=true;};el('ask').onclick=async()=>{if(source!=='live')return;el('agent-answer').textContent='Working…';try{const r=await api('/api/v1/agent/supervisor/chat',{method:'POST',timeout:60000,body:JSON.stringify({message:el('agent-question').value,site_id:current?.site_id||'SITE-01'})});el('agent-answer').textContent=r.response;}catch(e){el('agent-answer').textContent=e.message;}};
window.addEventListener('keydown',e=>{if(['INPUT','TEXTAREA','SELECT','BUTTON'].includes(document.activeElement?.tagName)||!el('agent').hidden)return;if(e.key===' '){e.preventDefault();playPause();}if(e.key==='.')step(1);if(e.key===',')step(-1);const verdict={t:'TRUE_POSITIVE',f:'FALSE_POSITIVE',c:'CONTROLLED_WORK'}[e.key.toLowerCase()];if(verdict)review(verdict);});
function freshness(){if(source==='live'&&current){const remaining=deadline-performance.now();if(remaining<=0)clear('Connection stale — monitoring unavailable');else el('live-age').textContent='Frame age '+Math.max(0,current.stale_after_seconds-remaining/1000).toFixed(1)+' s';}}
setInterval(freshness,100);document.addEventListener('visibilitychange',()=>{freshness();if(!document.hidden){resize();if(source==='demo'&&!playing)loadFrame(epoch);}});resize();clear('Loading recorded demo…');window.addEventListener('DOMContentLoaded',()=>refresh(true,true).catch(e=>clear(e.message)));

function createTwin(){
 const container=el('webgl-wrapper');let renderer,scene,camera,group,grid;let target={x:0,y:8},radius=42,azimuth=-Math.PI/2,elevation=.85,last=0,drag=null;const meshes=new Map();let hazardKey='',hazardGroup;
 function dispose(object){object.traverse?.(part=>{part.geometry?.dispose();if(Array.isArray(part.material))part.material.forEach(m=>m.dispose());else part.material?.dispose();});}
 function clear(){if(!group)return;for(const mesh of meshes.values()){group.remove(mesh);dispose(mesh);}meshes.clear();for(const child of [...hazardGroup.children]){hazardGroup.remove(child);dispose(child);}hazardKey='';}
 function resize(){if(!renderer)return;const w=Math.max(1,container.clientWidth),h=Math.max(1,container.clientHeight);renderer.setSize(w,h);camera.aspect=w/h;camera.updateProjectionMatrix();}
 try{
  if(typeof THREE==='undefined')throw Error();scene=new THREE.Scene();scene.background=new THREE.Color(0x0a0c0e);camera=new THREE.PerspectiveCamera(45,1,.1,2000);camera.up.set(0,0,1);renderer=new THREE.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));container.appendChild(renderer.domElement);grid=new THREE.GridHelper(80,80,0x282f37,0x161a1e);grid.rotation.x=Math.PI/2;scene.add(grid);group=new THREE.Group();scene.add(group);hazardGroup=new THREE.Group();scene.add(hazardGroup);resize();
  renderer.domElement.addEventListener('webglcontextlost',event=>{event.preventDefault();container.setAttribute('data-unavailable','3D view unavailable. Camera monitoring continues.');});
  container.onpointerdown=e=>{drag=[e.clientX,e.clientY];container.setPointerCapture(e.pointerId);};container.onpointerup=()=>drag=null;container.onpointermove=e=>{if(!drag)return;azimuth-=(e.clientX-drag[0])*.008;elevation=Math.max(.15,Math.min(1.5,elevation+(e.clientY-drag[1])*.005));drag=[e.clientX,e.clientY];};container.addEventListener('wheel',e=>{e.preventDefault();radius=Math.max(8,Math.min(150,radius+e.deltaY*.03));},{passive:false});
  function render(t){requestAnimationFrame(render);if(document.hidden||t-last<1000/30)return;last=t;camera.position.set(target.x+radius*Math.cos(elevation)*Math.cos(azimuth),target.y+radius*Math.cos(elevation)*Math.sin(azimuth),radius*Math.sin(elevation));camera.lookAt(target.x,target.y,0);renderer.render(scene,camera);}requestAnimationFrame(render);
 }catch(e){container.textContent='3D view unavailable in this browser. Camera monitoring and reviews remain available.';return {update(){},clear(){},resize(){}};}
 function update(packet){
  const ids=new Set(), alertIds=new Set((packet.evaluated_pairs||[]).filter(p=>p.risk.state!=='NORMAL_LEVEL_0').flatMap(p=>[p.track_a,p.track_b]));for(const track of packet.tracks||[]){if(track.last_observed_age_seconds>1)continue;const id=track.track_id;ids.add(id);let mesh=meshes.get(id);if(!mesh){mesh=new THREE.Group();const human=track.class_id<2;const body=new THREE.Mesh(human?new THREE.CylinderGeometry(.3,.3,1.8,12):new THREE.BoxGeometry(2.6,5,1.8),new THREE.MeshBasicMaterial({color:human?0x60a5fa:0xf59e0b}));if(human)body.rotation.x=Math.PI/2;body.position.z=.9;mesh.add(body);if(!human){const cab=new THREE.Mesh(new THREE.BoxGeometry(1.8,2,1.2),new THREE.MeshBasicMaterial({color:0x2563eb}));cab.position.set(0,.5,2.2);mesh.add(cab);}mesh.userData.paths=new THREE.Group();mesh.add(mesh.userData.paths);meshes.set(id,mesh);group.add(mesh);}mesh.position.set(track.position[0],track.position[1],0);const paths=mesh.userData.paths;for(const child of [...paths.children]){paths.remove(child);dispose(child);}if(alertIds.has(id)){const ring=new THREE.Mesh(new THREE.RingGeometry(1,1.35,32),new THREE.MeshBasicMaterial({color:0xef4444,side:THREE.DoubleSide}));ring.position.z=.12;paths.add(ring);}for(const [points,color] of [[track.history,0x64748b],[track.forecast_trajectory,track.class_id<2?0x38bdf8:0xfbbf24]]){if(points?.length>1){const geometry=new THREE.BufferGeometry().setFromPoints(points.map(p=>new THREE.Vector3(p[0]-track.position[0],p[1]-track.position[1],.15)));paths.add(new THREE.Line(geometry,new THREE.LineBasicMaterial({color})));}}}
  for(const [id,mesh] of meshes){if(!ids.has(id)){group.remove(mesh);dispose(mesh);meshes.delete(id);}}
  const hazards=packet.hazards||[],key=JSON.stringify(hazards);if(key!==hazardKey){for(const child of [...hazardGroup.children]){hazardGroup.remove(child);dispose(child);}hazardKey=key;for(const hazard of hazards){const poly=hazard.polygon||hazard.polygon_metric_epsg3857;if(!poly?.length)continue;const shape=new THREE.Shape(poly.map(p=>new THREE.Vector2(p[0],p[1])));const zone=new THREE.Mesh(new THREE.ShapeGeometry(shape),new THREE.MeshBasicMaterial({color:0xef4444,transparent:true,opacity:.18,side:THREE.DoubleSide}));zone.position.z=.04;hazardGroup.add(zone);}}
  const tracks=packet.tracks||[];if(tracks.length){const x=tracks.reduce((s,t)=>s+t.position[0],0)/tracks.length,y=tracks.reduce((s,t)=>s+t.position[1],0)/tracks.length;if(Math.hypot(target.x-x,target.y-y)>20){target={x,y};grid.position.set(x,y,0);}}
 }
 return {update,clear,resize};
}
